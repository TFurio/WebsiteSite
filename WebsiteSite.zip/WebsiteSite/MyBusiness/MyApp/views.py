from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'Home.html')

def contact(request):
    return render(request, 'Contact.html')

def gallery(request):
    return render(request, 'Contact.html')

def services(request):
    return render(request, 'services.html')
    
def examples(request):
    return render(request, 'services.html')